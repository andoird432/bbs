<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: supesite.php,v $
	$Revision: 1.1.2.2 $
	$Date: 2007/03/21 15:52:37 $
*/

chdir('../');
require_once './include/common.inc.php';

if($action == 'updatecache') {
	$expiration = intval(authcode($verify, 'DECODE'));
	if($expiration && $timestamp - $expiration < 10 && $timestamp - $expiration > 0) {
		include_once DISCUZ_ROOT.'./include/cache.func.php';
		updatecache();
		die('1');
	} else {
		die('0');
	}
}

?>