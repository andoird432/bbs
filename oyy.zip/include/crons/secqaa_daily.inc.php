<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: secqaa_daily.inc.php,v $
	$Revision: 1.1.2.1 $
	$Date: 2007/03/21 15:53:02 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($secqaa['status'] > 0) {
	require_once DISCUZ_ROOT.'./include/cache.func.php';
	updatecache('secqaa');
}

?>