<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: supe_daily.inc.php,v $
	$Revision: 1.7.2.2 $
	$Date: 2007/03/21 15:53:02 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($supe['status'] && $supe['maxupdateusers']) {
	require_once DISCUZ_ROOT.'./include/cache.func.php';
	updatecache(array('supe_updateusers', 'supe_updateitems'));
}

?>