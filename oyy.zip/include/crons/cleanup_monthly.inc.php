<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: cleanup_monthly.inc.php,v $
	$Revision: 1.7.4.3 $
	$Date: 2007/03/21 15:53:02 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$myrecordtimes = $timestamp - $_DCACHE['settings']['myrecorddays'] * 86400;
$db->query("DELETE FROM {$tablepre}mythreads WHERE dateline<'$myrecordtimes'", 'UNBUFFERED');
$db->query("DELETE FROM {$tablepre}myposts WHERE dateline<'$myrecordtimes'", 'UNBUFFERED');

$db->query("TRUNCATE {$tablepre}relatedthreads");

?>