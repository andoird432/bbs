<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: todayposts_daily.inc.php,v $
	$Revision: 1.3.10.2 $
	$Date: 2007/03/21 15:53:02 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$query = $db->query("SELECT sum(todayposts) FROM {$tablepre}forums");
$yesterdayposts = $_DCACHE['settings']['yesterdayposts'] = intval($db->result($query, 0));
$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('yesterdayposts', $yesterdayposts)");
$db->query("UPDATE {$tablepre}forums SET todayposts='0'");

?>