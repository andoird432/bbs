/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: onlines.js,v $
	$Revision: 1.2.2.2 $
	$Date: 2007/03/21 15:53:02 $
*/

document.write('<span id="onlinenum"></span>');
getonlinenum();
function getonlinenum() {
	var x = new Ajax();
	x.get('misc.php?action=getonlines&inajax=yes', function(s){
		$('onlinenum').innerHTML = s;
	});
}
window.setInterval("getonlinenum()", 180000);