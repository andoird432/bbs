<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: pushthreads.inc.php,v $
	$Revision: 1.19.2.1 $
	$Date: 2007/03/21 15:52:03 $
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
}

cpheader();

if(empty($operation) || $operation == 'list') {

	$tpp = 5;

	shownav('menu_passport_pushthreads');
	showtips('pushthreads_tips');
	$page = max(1, intval($page));
	$startlimit = ($page - 1) * $tpp;

	switch($filter) {
		case 'ignore': 	$filteradd = 'status=1'; break;
		case 'pushed': 	$filteradd = 'status=2'; break;
		case 'all':	$filteradd = '1'; break;
		default:	$filteradd = 'status=0'; $filter = 'none';
	}

	if(isset($id) && $id = intval($id)) {
		$filteradd .= " AND id='$id'";
	}

	$query = $db->query("SELECT COUNT(*) from {$tablepre}pushedthreads where $filteradd");
	$threadnums = $db->result($query, 0);

	$pushedthreads = $multipage = '';
	if($threadnums) {
		$multipage = multi($threadnums, $tpp, $page, 'admincp.php?action=pushthreads&operation=list&filter='.$filter);

		$query = $db->query("SELECT * FROM {$tablepre}pushedthreads WHERE $filteradd ORDER BY dateline DESC LIMIT $startlimit, $tpp");
		while($thread = $db->fetch_array($query)) {

			$thread['dateline'] = gmdate("$dateformat $timeformat", $thread['dateline'] + $timeoffset * 3600);
			$thread['message'] = nl2br($thread['message']);


			if($thread['status'] == 2 && $thread['tid']) {
				$thread['subject'] = "<a href=\"viewthread.php?tid={$thread['tid']}\" target=\"_blank\" title=\"".$lang['new_windows']."\">{$thread['subject']}</a>";
			}

			$status = $addstyle = '';
			if($filter == 'all') {
				switch($thread['status']) {
					case 0: $status = '['.$lang['pushthreads_doesnt_commend'].']'; break;
					case 1: $status = '['.$lang['pushthreads_ignore'].']'; $addstyle= ' style="color: #AAAAAA;"';break;
					case 2: $status = '['.$lang['pushthreads_commend'].']'; break;
				}
			}

			$pushedthreads .= '<tr'.$addstyle.'><td class="altbg1" align="center" rowspan="2"><input class="checkbox" type="checkbox" name="pushid[]" value="'.$thread['id'].'"></td>'.
				'<td class="altbg1" style="padding: 0px;"><div style="float: left">'.$status.' <span class="bold">'.$thread['subject'].'</span></div>'.
				'<div>'.$thread['dateline']."</div></td></tr>\n".
				'<tr'.$addstyle.'><td class="altbg2"  style="padding: 0px;"><div style="border-style: dotted; border-width: 1px; border-color: '.BORDERCOLOR.'; padding-left: 0px; overflow: auto; overflow-y: scroll; width: 600px; height:120px; word-break: break-all">'.$thread[message]."</div></td></tr>\n";
		}
	} else {
		$pushedthreads = '<tr><td class="altbg1" colspan="2">'.$lang['pushthreads_nofind'].'</td></tr>';
	}

	shownavheader($filter);

?>

<form method="post" action="admincp.php?action=pushthreads">
<input type="hidden" name="formhash" value="<?=FORMHASH?>">
<input type="hidden" name="filter" value="<?=$filter?>">
<input type="hidden" name="page" value="<?=$page?>">

<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">
<tr class="header"><td width="5%"></td>
<td width="95%"><?=$lang['pushthreads_thread']?></td></tr>
<?=$pushedthreads?>
<? if($threadnums) { ?>
<tr align="center"><td class="altbg1"><?=$lang['operation']?></td>
<td class="altbg2">
<input class="checkbox" type="checkbox" name="chkall" onclick="checkall(this.form, 'pushid');"> <?=$lang['select_all']?>
&nbsp;&nbsp;<input class="radio" type="radio" name="operation" value="push" checked> <?=$lang['pushthreads_push_forum']?>
&nbsp;&nbsp;<input class="radio" type="radio" name="operation" value="ignore"> <?=$lang['pushthreads_thread_ignore']?>
&nbsp;&nbsp;<input class="button" type="submit" name="submit" value="<?=$lang['submit']?>">
</td></tr>
<? } ?>
</table></form>
<?=$multipage?>

<?

} elseif($operation == 'push') {

	if($pushids = implodeids($pushid)) {
		$query = $db->query("SELECT * FROM {$tablepre}pushedthreads WHERE id IN($pushids)");
		$pushids = $comma = '';
		while($thread = $db->fetch_array($query)) {
			$threadlist[] = $thread;
			$pushids .= $comma.$thread['id'];
			$comma = ',';
		}
	}

	if(empty($threadlist)) {
		cpmsg('pushthreads_choice_error');
	}

	require_once DISCUZ_ROOT.'./include/forum.func.php';

	$forumselect = '<select name="inforum">'.forumselect().'</select>';

	if(isset($inforum)) {
		$inforum = intval($inforum);
		$forumselect = preg_replace("/(\<option value=\"$inforum\")(\>)/", "\\1 selected=\"selected\" \\2", $forumselect);

		$query = $db->query("SELECT * FROM {$tablepre}forums WHERE fid='$inforum' AND status>0 AND type<>'group'");
		$forum = $db->fetch_array($query);
	}

	if(!submitcheck('pushsubmit')) {

		showtips('pushthreads_tips');

?>
<br><form method="post" action="admincp.php?action=pushthreads">
<input type="hidden" name="formhash" value="<?=FORMHASH?>">
<input type="hidden" name="operation" value="push">
<input type="hidden" name="filter" value="<?=$filter?>">
<input type="hidden" name="page" value="<?=$page?>">

<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">
<tr class="header">
<td colspan="2"><?=$lang['pushthreads_thread_to_forum']?></td>
</tr>

<tr>
<td class="altbg1" width="30%"><?=$lang['threads_search_forum']?></td>
<td class="altbg2" width="70%"><?=$forumselect?></td>
</tr>

<tr>
<td class="altbg1"><?=$lang['pushthreads_stick_conf']?></td>
<td class="altbg2">
<input class="radio" type="radio" name="stick_level" value="0" checked> <?=$lang['none']?> &nbsp; &nbsp;
<input class="radio" type="radio" name="stick_level" value="1"> <img src="<?=IMGDIR?>/star_level1.gif"> &nbsp; &nbsp;
<input class="radio" type="radio" name="stick_level" value="2"> <img src="<?=IMGDIR?>/star_level1.gif"><img src="<?=IMGDIR?>/star_level1.gif"> &nbsp; &nbsp;
<input class="radio" type="radio" name="stick_level" value="3"> <img src="<?=IMGDIR?>/star_level1.gif"><img src="<?=IMGDIR?>/star_level1.gif"><img src="<?=IMGDIR?>/star_level1.gif"></td>
</tr>

<tr>
<td class="altbg1"><?=$lang['pushthreads_digest_conf']?></td>
<td class="altbg2">
<input class="radio" type="radio" name="digest_level" value="0"  checked> <?=$lang['none']?> &nbsp; &nbsp;
<input class="radio" type="radio" name="digest_level" value="1"> <img src="<?=IMGDIR?>/star_level1.gif"> &nbsp; &nbsp;
<input class="radio" type="radio" name="digest_level" value="2"> <img src="<?=IMGDIR?>/star_level1.gif"><img src="<?=IMGDIR?>/star_level1.gif"> &nbsp; &nbsp;
<input class="radio" type="radio" name="digest_level" value="3"> <img src="<?=IMGDIR?>/star_level1.gif"><img src="<?=IMGDIR?>/star_level1.gif"><img src="<?=IMGDIR?>/star_level1.gif"></td>
</tr>

<tr>
<td class="altbg1"><?=$lang['pushthreads_title_style']?>:</td>
<td class="altbg2">
<input class="checkbox" type="checkbox" name="highlight_style[1]" value="1" checked> <b><?=$lang['pushthreads_bold']?></b>&nbsp;
<input class="checkbox" type="checkbox" name="highlight_style[2]" value="1"> <i><?=$lang['pushthreads_italic']?></i>&nbsp;
<input class="checkbox" type="checkbox" name="highlight_style[3]" value="1"> <u><?=$lang['pushthreads_underline']?></u>
</td>
</tr>

<tr>
<td class="altbg1"><?=$lang['pushthreads_title_color']?>:</td>
<td class="altbg2">
<table border="0" cellspacing="0" cellpadding="0"><tr>
<td><input class="radio" type="radio" name="highlight_color" value="0" $colorcheck[0]></td><td width="40"><?=$lang['default']?></td>
<td> &nbsp; <input class="radio" type="radio" name="highlight_color" value="1" checked></td><td width="20" style="background: red">&nbsp;</td>
<td> &nbsp; <input class="radio" type="radio" name="highlight_color" value="2"></td><td width="20" style="background: orange">&nbsp;</td>
<td> &nbsp; <input class="radio" type="radio" name="highlight_color" value="3"></td><td width="20" style="background: yellow">&nbsp;</td>
<td> &nbsp; <input class="radio" type="radio" name="highlight_color" value="4"></td><td width="20" style="background: green">&nbsp;</td>
<td> &nbsp; <input class="radio" type="radio" name="highlight_color" value="5"></td><td width="20" style="background: cyan">&nbsp;</td>
<td> &nbsp; <input class="radio" type="radio" name="highlight_color" value="6"></td><td width="20" style="background: blue">&nbsp;</td>
<td> &nbsp; <input class="radio" type="radio" name="highlight_color" value="7"></td><td width="20" style="background: purple">&nbsp;</td>
<td> &nbsp; <input class="radio" type="radio" name="highlight_color" value="8"></td><td width="20" style="background: gray">&nbsp;</td>
</tr></table>
</td></tr>
</table><br>

<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">
<tr class="header">
<td colspan="2"><?=$lang['pushthreads_selected_thread']?></td>
</tr>
<?

		foreach($threadlist as $thread) {

			echo '<tr><td class="altbg1" width="5%" align="center"><input class="checkbox" type="checkbox" name="pushid[]" value="'.$thread['id'].'" checked></td>'.
				'<td class="altbg2" width="95%">'.$thread['subject']."</td></tr>\n";

		}

		echo '</table><br><center><input class="button" type="submit" name="pushsubmit" value="'.$lang['submit'].'"></center></form>';

	} else {

		if(empty($inforum) || empty($forum)) {
			cpmsg('pushthreads_selected_forum_error');
		}

		$fid = $forum['fid'];
		$digest_level = intval($digest_level);
		$stick_level = intval($stick_level);

		$stylebin = '';
		for($i = 1; $i <= 3; $i++) {
			$stylebin .= empty($highlight_style[$i]) ? '0' : '1';
		}

		$highlight = min(7, max(0, bindec($stylebin))).min(8, max(0, intval($highlight_color)));

		foreach($threadlist as $thread) {
			$timestamp ++;
			$thread['message'] = addslashes($thread['message']);
			$thread['subject'] = addslashes($thread['subject']);
			$db->query("INSERT INTO {$tablepre}threads (fid, author, authorid, subject, dateline, lastpost, lastposter, displayorder, digest, highlight)
				VALUES ('$fid', '$discuz_user', '$discuz_uid', '$thread[subject]', '$timestamp', '$timestamp', '$discuz_user', '$stick_level', '$digest_level', '$highlight')");
			$tid = $db->insert_id();

			$db->query("INSERT INTO {$tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, anonymous, usesig, htmlon, bbcodeoff, smileyoff, parseurloff)
				VALUES ('$fid', '$tid', '1', '$discuz_user', '$discuz_uid', '$thread[subject]', '$timestamp', '$thread[message]', '$onlineip', '0', '0', '1', '0', '0', '0', '0')");
			$db->query("UPDATE {$tablepre}pushedthreads SET status=2, tid='$tid' WHERE id='$thread[id]'", 'UNBUFFERED');
		}

		$lastpost = "$tid\t{$thread['subject']}\t$timestamp\t$discuz_user";
		$db->query("UPDATE {$tablepre}forums SET lastpost='$lastpost', threads=threads+1, posts=posts+1, todayposts=todayposts+1 WHERE fid='$fid'", 'UNBUFFERED');
		if($forum['type'] == 'sub') {
			$db->query("UPDATE {$tablepre}forums SET lastpost='$lastpost' WHERE fid='$forum[fup]'", 'UNBUFFERED');
		}

		cpmsg('pushthreads_finish', 'admincp.php?action=pushthreads&operation=list&filter='.$filter.'&page='.$page);

	}


} elseif($operation == 'ignore') {

	$threadlist = $hidden = '';
	if($pushids = implodeids($pushid)) {
		$query = $db->query("SELECT id, subject FROM {$tablepre}pushedthreads WHERE id IN($pushids)");
		$pushids = $comma = '';
		while($thread = $db->fetch_array($query)) {
			$pushids .= $comma.$thread['id'];
			$comma = ',';
			$threadlist .= '<li>'.$thread['subject'];
			$hidden .= "<input type=\"hidden\" name=\"pushid[]\" value=\"$thread[id]\">\n";
		}
	}

	if(empty($threadlist)) {
		cpmsg('pushthreads_selected_error');
	}

	if(!submitcheck('confirmed')) {
		cpmsg('pushthreads_ignore_confirm', 'admincp.php?action=pushthreads&operation=ignore', 'form', "<div style=\"text-align: left\"><ul>$threadlist</ul></div>\n$hidden");
	} else {
		$db->query("UPDATE {$tablepre}pushedthreads SET status='1' WHERE id IN($pushids)", 'UNBUFFERED');
		cpmsg('pushthreads_ignore_finish', 'admincp.php?action=pushthreads&operation=list&filter=all');
	}


} else {

	cpmsg('noaccess');

}

function shownavheader($filter) {
	global $lang;
	$navstyle = array('ignore' => 'altbg2', 'pushed' => 'altbg2', 'all' => 'altbg2', 'none' => 'altbg2');
	$navblod = array('ignore' => '', 'pushed' => '', 'all' => '', 'none' => '');

	$navstyle[$filter] = 'altbg1';
	$navbold[$filter] = 'style="font: bold"';

	echo "\n".'<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">'.
		'<tr class="header">'."\n".
		'<td class="'.$navstyle['all'].'" width="25%"><a href="admincp.php?action=pushthreads&filter=all" '.$navbold['all'].'>'.$lang['pushthreads_all_thread'].'</a></td>'."\n".
		'<td class="'.$navstyle['none'].'" width="25%"><a href="admincp.php?action=pushthreads&filter=none" '.$navbold['none'].'>'.$lang['pushthreads_doesnt_commend_thread'].'</td>'."\n".
		'<td class="'.$navstyle['pushed'].'" width="25%"><a href="admincp.php?action=pushthreads&filter=pushed" '.$navbold['pushed'].'>'.$lang['pushthreads_commend_thread'].'</td>'."\n".
		'<td class="'.$navstyle['ignore'].'" width="25%"><a href="admincp.php?action=pushthreads&filter=ignore" '.$navbold['ignore'].'>'.$lang['pushthreads_ignore_thread'].'</td>'."\n".
		'</tr></table>'.
		"<br>\n";

}

?>