<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: settings.inc.php,v $
	$Revision: 1.157.2.25 $
	$Date: 2007/03/30 14:46:25 $
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

function creditsrow($rowname) {
	global $settings;
	$policyrow = '';
	for($i = 1; $i <= 8; $i++) {
		$policyrow .="<td ".($settings['extcredits'][$i]['available'] ? '' : 'disabled')." class=\"altbg".(is_int($i/2) ? 1 : 2)."\"><input type=\"text\" size=\"2\" name=\"settingsnew[creditspolicy][$rowname][$i]\" ".($settings['extcredits'][$i]['available'] ? '' : 'readonly')." value=\"".intval($settings['creditspolicy'][$rowname][$i])."\"></td>";
	}
	return $policyrow;
}

cpheader();

$query = $db->query("SELECT * FROM {$tablepre}settings");
while($setting = $db->fetch_array($query)) {
	$settings[$setting['variable']] = $setting['value'];
}

$extbutton = '';
$settings['ftp'] = unserialize($settings['ftp']);
$settings['ftp']['password'] = authcode($settings['ftp']['password'], 'DECODE', md5($authkey));

if(!submitcheck('settingsubmit')) {


	shownav($do == 'basic' ? 'settings_general' : 'settings_'.$do);

?>
<form method="post" name="settings" id="settings" action="admincp.php?action=settings&edit=yes">
<input type="hidden" name="formhash" value="<?=FORMHASH?>">
<input type="hidden" name="do" value="<?=$do?>">
<?

	if($do == 'access') {

		$checkrf = array($settings['regverify'] => 'checked');
		$wmsgcheck = array($settings['welcomemsg'] =>'checked');

		showtype('settings_subtitle_register', 'top', 'settingsubmit');
		showsetting('settings_regstatus', 'settingsnew[regstatus]', $settings['regstatus'], 'radio');
		showsetting('settings_register_advanced', 'settingsnew[regadvance]', $settings['regadvance'], 'radio');
		showsetting('settings_censoruser', 'settingsnew[censoruser]', $settings['censoruser'], 'textarea');
		showsetting('settings_regverify', '', '', '<input class="radio" type="radio" name="settingsnew[regverify]" value="0" '.$checkrf[0].'> '.$lang['none'].'<br><input class="radio" type="radio" name="settingsnew[regverify]" value="1" '.$checkrf[1].'> '.$lang['settings_regverify_email'].'<br><input class="radio" type="radio" name="settingsnew[regverify]" value="2" '.$checkrf[2].'> '.$lang['settings_regverify_manual']);
		showsetting('settings_doublee', 'settingsnew[doublee]', $settings['doublee'], 'radio');
		showsetting('settings_email_allowurl', 'settingsnew[accessemail]', $settings['accessemail'], 'textarea');
		showsetting('settings_censoremail', 'settingsnew[censoremail]', $settings['censoremail'], 'textarea');
		showsetting('settings_regctrl', 'settingsnew[regctrl]', $settings['regctrl'], 'text');
		showsetting('settings_regfloodctrl', 'settingsnew[regfloodctrl]', $settings['regfloodctrl'], 'text');
		showsetting('settings_newbiespan', 'settingsnew[newbiespan]', $settings['newbiespan'], 'text');
		showsetting('settings_welcomemsg', '', '', '<input class="radio" type="radio" name="settingsnew[welcomemsg]" value="0" '.$wmsgcheck[0].'> '.$lang['settings_welcomemsg_nosend'].' <br><input class="radio" type="radio" name="settingsnew[welcomemsg]" value="1" '.$wmsgcheck[1].'> '.$lang['settings_welcomemsg_pm'].' <br><input class="radio" type="radio" name="settingsnew[welcomemsg]" value="2" '.$wmsgcheck[2].'> '.$lang['settings_welcomemsg_email']);
		showsetting('settings_welcomemsgtitle', 'settingsnew[welcomemsgtitle]', $settings['welcomemsgtitle'], 'text');
		showsetting('settings_welcomemsgtxt', 'settingsnew[welcomemsgtxt]', $settings['welcomemsgtxt'], 'textarea');
		showsetting('settings_bbrules', 'settingsnew[bbrules]', $settings['bbrules'], 'radio');
		showsetting('settings_bbrulestxt', 'settingsnew[bbrulestxt]', $settings['bbrulestxt'], 'textarea');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_access', 'top', 'settingsubmit');
		showsetting('settings_ipregctrl', 'settingsnew[ipregctrl]', $settings['ipregctrl'], 'textarea');
		showsetting('settings_ipaccess', 'settingsnew[ipaccess]', $settings['ipaccess'], 'textarea');
		showsetting('settings_adminipaccess', 'settingsnew[adminipaccess]', $settings['adminipaccess'], 'textarea');

	} elseif($do == 'styles') {

		$stylelist = "<select name=\"settingsnew[styleid]\">\n";
		$query = $db->query("SELECT styleid, name FROM {$tablepre}styles");
		while($style = $db->fetch_array($query)) {
			$selected = $style['styleid'] == $settings['styleid'] ? 'selected="selected"' : NULL;
			$stylelist .= "<option value=\"$style[styleid]\" $selected>$style[name]</option>\n";
		}
		$stylelist .= '</select>';

		$checkmoddisplay = array($settings['moddisplay'] => 'checked');
		$checkvtonline = array($settings['vtonlinestatus'] => 'checked');
		$checkonline = array($settings['whosonlinestatus'] => 'checked');
		$checkstatusby = array($settings['userstatusby'] => 'checked');
		$frameonchecked = array($settings['frameon'] => 'checked');
		$showsettings = str_pad(decbin($settings['showsettings']), 3, 0, STR_PAD_LEFT);
		$settings['showsignatures'] = $showsettings{0};
		$settings['showavatars'] = $showsettings{1};
		$settings['showimages'] = $showsettings{2};

		showtips('settings_tips');
		showtype('settings_subtitle_style', 'top', 'settingsubmit');
		showsetting('settings_styleid', '', '', $stylelist);
		showsetting('settings_stylejump', 'settingsnew[stylejump]', $settings['stylejump'], 'radio');
		showsetting('settings_frameon', 'settingsnew[frameon]', $settings['frameon'], '<input class="radio" type="radio" name="settingsnew[frameon]" value="0" '.$frameonchecked[0].'> '.$lang['settings_frameon_0'].'<br><input class="radio" type="radio" name="settingsnew[frameon]" value="1" '.$frameonchecked[1].'> '.$lang['settings_frameon_1'].'<br><input class="radio" type="radio" name="settingsnew[frameon]" value="2" '.$frameonchecked[2].'> '.$lang['settings_frameon_2']);
		showsetting('settings_framewidth', 'settingsnew[framewidth]', $settings['framewidth'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_index', 'top', 'settingsubmit');
		showsetting('settings_subforumsindex', 'settingsnew[subforumsindex]', $settings['subforumsindex'], 'radio');
		showsetting('settings_forumlinkstatus', 'settingsnew[forumlinkstatus]', $settings['forumlinkstatus'], 'radio');
		showsetting('settings_moddisplay', '', '', '<input class="radio" type="radio" name="settingsnew[moddisplay]" value="flat" '.$checkmoddisplay['flat'].'> '.$lang['settings_moddisplay_flat'].' &nbsp; <input class="radio" type="radio" name="settingsnew[moddisplay]" value="selectbox" '.$checkmoddisplay['selectbox'].'> '.$lang['settings_moddisplay_selectbox']);
		showsetting('settings_index_members', 'settingsnew[maxbdays]', $settings['maxbdays'], 'text');
		showsetting('settings_whosonline', '', '', '<input class="radio" type="radio" name="settingsnew[whosonlinestatus]" value="0" '.$checkonline[0].'> '.$lang['settings_display_none'].'<br><input class="radio" type="radio" name="settingsnew[whosonlinestatus]" value="1" '.$checkonline[1].'> '.$lang['settings_whosonline_index'].'<br><input class="radio" type="radio" name="settingsnew[whosonlinestatus]" value="2" '.$checkonline[2].'> '.$lang['settings_whosonline_forum'].'<br><input class="radio" type="radio" name="settingsnew[whosonlinestatus]" value="3" '.$checkonline[3].'> '.$lang['settings_whosonline_both']);
		showsetting('settings_whosonline_contract', 'settingsnew[whosonline_contract]', $settings['whosonline_contract'], 'radio');
		showsetting('settings_online_more_members', 'settingsnew[maxonlinelist]', $settings['maxonlinelist'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_forumdisplay', 'top', 'settingsubmit');
		showsetting('settings_tpp', 'settingsnew[topicperpage]', $settings['topicperpage'], 'text');
		showsetting('settings_threadmaxpages', 'settingsnew[threadmaxpages]', $settings['threadmaxpages'], 'text');
		showsetting('settings_hottopic', 'settingsnew[hottopic]', $settings['hottopic'], 'text');
		showsetting('settings_fastpost', 'settingsnew[fastpost]', $settings['fastpost'], 'radio');
		showsetting('settings_globalstick', 'settingsnew[globalstick]', $settings['globalstick'], 'radio');
		showsetting('settings_stick', 'settingsnew[threadsticky]', $settings['threadsticky'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_viewthread', 'top', 'settingsubmit');
		showsetting('settings_ppp', 'settingsnew[postperpage]', $settings['postperpage'], 'text');
		showsetting('settings_starthreshold', 'settingsnew[starthreshold]', $settings['starthreshold'], 'text');
		showsetting('settings_maxsigrows', 'settingsnew[maxsigrows]', $settings['maxsigrows'], 'text');
		showsetting('settings_rate_number', 'settingsnew[ratelogrecord]', $settings['ratelogrecord'], 'text');
		showsetting('settings_show_signature', 'settingsnew[showsignatures]', $settings['showsignatures'], 'radio');
		showsetting('settings_show_face', 'settingsnew[showavatars]', $settings['showavatars'], 'radio');
		showsetting('settings_show_images', 'settingsnew[showimages]', $settings['showimages'], 'radio');
		showsetting('settings_vtonlinestatus', '', '','<input class="radio" type="radio" name="settingsnew[vtonlinestatus]" value="0" '.$checkvtonline[0].'> '.$lang['settings_display_none'].'<br><input class="radio" type="radio" name="settingsnew[vtonlinestatus]" value="1" '.$checkvtonline[1].'> '.$lang['settings_online_easy'].'<br><input class="radio" type="radio" name="settingsnew[vtonlinestatus]" value="2" '.$checkvtonline[2].'> '.$lang['settings_online_exactitude']);
		showsetting('settings_userstatusby', '', '', '<input class="radio" type="radio" name="settingsnew[userstatusby]" value="0" '.$checkstatusby[0].'> '.$lang['settings_display_none'].'<br><input class="radio" type="radio" name="settingsnew[userstatusby]" value="1" '.$checkstatusby[1].'> '.$lang['usergroup'].'<br><input class="radio" type="radio" name="settingsnew[userstatusby]" value="2" '.$checkstatusby[2].'> '.$lang['rank']);
		showsetting('settings_maxsmilies', 'settingsnew[maxsmilies]', $settings['maxsmilies'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_member', 'top', 'settingsubmit');
		showsetting('settings_mpp', 'settingsnew[memberperpage]', $settings['memberperpage'], 'text');
		showsetting('settings_membermaxpages', 'settingsnew[membermaxpages]', $settings['membermaxpages'], 'text');
		echo '</tbody></table><br>';

		$settings['msgforward'] = !empty($settings['msgforward']) ? unserialize($settings['msgforward']) : array();
		$settings['msgforward']['messages'] = !empty($settings['msgforward']['messages']) ? implode("\n", $settings['msgforward']['messages']) : '';

		showtype('settings_subtitle_refresh', 'top', 'settingsubmit');
		showsetting('settings_refresh_refreshtime', 'settingsnew[msgforward][refreshtime]', $settings['msgforward']['refreshtime'], 'text');
		showsetting('settings_refresh_quick', 'settingsnew[msgforward][quick]', $settings['msgforward']['quick'], 'radio');
		showsetting('settings_refresh_messages', 'settingsnew[msgforward][messages]', $settings['msgforward']['messages'], 'textarea');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_other', 'top', 'settingsubmit');
		showsetting('settings_hideprivate', 'settingsnew[hideprivate]', $settings['hideprivate'], 'radio');
		showsetting('settings_visitedforums', 'settingsnew[visitedforums]', $settings['visitedforums'], 'text');

	} elseif($do == 'seo') {

		$checkarchiver = array($settings['archiverstatus'] => 'checked');
		$checkrewrite = array($settings['rewritestatus'] => 'checked');

		showtips('settings_tips');
		showtype('settings_seo', 'top', 'settingsubmit');
		showsetting('settings_archiverstatus', '', '', '<input class="radio" type="radio" name="settingsnew[archiverstatus]" value="0" '.$checkarchiver[0].'> '.$lang['settings_archiverstatus_none'].'<br><input class="radio" type="radio" name="settingsnew[archiverstatus]" value="1" '.$checkarchiver[1].'> '.$lang['settings_archiverstatus_full'].'<br><input class="radio" type="radio" name="settingsnew[archiverstatus]" value="2" '.$checkarchiver[2].'> '.$lang['settings_archiverstatus_searchengine'].'<br><input class="radio" type="radio" name="settingsnew[archiverstatus]" value="3" '.$checkarchiver[3].'> '.$lang['settings_archiverstatus_browser']);
		showsetting('settings_rewritestatus', '', '', '<input class="radio" type="radio" name="settingsnew[rewritestatus]" value="0" '.$checkrewrite[0].'> '.$lang['none'].'<br><input class="radio" type="radio" name="settingsnew[rewritestatus]" value="1" '.$checkrewrite[1].'> '.$lang['settings_rewritestatus_archiver'].'<br><input class="radio" type="radio" name="settingsnew[rewritestatus]" value="2" '.$checkrewrite[2].'> '.$lang['settings_rewritestatus_pages'].'<br><input class="radio" type="radio" name="settingsnew[rewritestatus]" value="3" '.$checkrewrite[3].'> '.$lang['settings_rewritestatus_both']);
		showsetting('settings_seotitle', 'settingsnew[seotitle]', $settings['seotitle'], 'text');
		showsetting('settings_seokeywords', 'settingsnew[seokeywords]', $settings['seokeywords'], 'text');
		showsetting('settings_seodescription', 'settingsnew[seodescription]', $settings['seodescription'], 'text');
		showsetting('settings_seohead', 'settingsnew[seohead]', $settings['seohead'], 'textarea');

	} elseif($do == 'functions') {

		$jsmenu = array();
		$settings['jsmenustatus'] = sprintf('%b', $settings['jsmenustatus']);
		for($i = 1; $i <= strlen($settings['jsmenustatus']); $i++) {
			$jsmenu[$i] = substr($settings['jsmenustatus'], -$i, 1) ? 'checked' : '';
		}

		$editoroptions = str_pad(decbin($settings['editoroptions']), 2, 0, STR_PAD_LEFT);
		$settings['defaulteditormode'] = $editoroptions{0};
		$settings['allowswitcheditor'] = $editoroptions{1};
		$checkeditormode = array($settings['defaulteditormode'] ? 1 : 0 => 'checked');

		showtips('settings_tips');
		showtype('settings_subtitle_menu', 'top', 'settingsubmit');
		showsetting('settings_jsmenu', 'settingsnew[forumjump]', $settings['forumjump'], 'radio');
		showsetting('settings_jsmenu_enable', '', '', '<input class="checkbox" type="checkbox" name="settingsnew[jsmenustatus][1]" value="1" '.$jsmenu[1].'> '.$lang['settings_jsmenu_enable_jump'].'<br><input class="checkbox" type="checkbox" name="settingsnew[jsmenustatus][2]" value="1" '.$jsmenu[2].'> '.$lang['settings_jsmenu_enable_memcp'].'<br><input class="checkbox" type="checkbox" name="settingsnew[jsmenustatus][3]" value="1" '.$jsmenu[3].'> '.$lang['settings_jsmenu_enable_stat'].'<br><input class="checkbox" type="checkbox" name="settingsnew[jsmenustatus][4]" value="1" '.$jsmenu[4].'> '.$lang['settings_jsmenu_enable_my'].'<br>');
		showsetting('settings_pluginjsmenu', 'settingsnew[pluginjsmenu]', $settings['pluginjsmenu'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_editor', 'top', 'settingsubmit');
		showsetting('settings_editor_mode_default', 'settingsnew[defaulteditormode]', $settings['defaulteditormode'], '<input class="radio" type="radio" name="settingsnew[defaulteditormode]" value="0" '.$checkeditormode[0].'> '.$lang['settings_editor_mode_discuzcode'].' <input class="radio" type="radio" name="settingsnew[defaulteditormode]" value="1" '.$checkeditormode[1].'> '.$lang['settings_editor_mode_wysiwyg']);
		showsetting('settings_editor_swtich_enable', 'settingsnew[allowswitcheditor]', $settings['allowswitcheditor'], 'radio');
		showsetting('settings_bbinsert', 'settingsnew[bbinsert]', $settings['bbinsert'], 'radio');
		showsetting('settings_smileyinsert', 'settingsnew[smileyinsert]', $settings['smileyinsert'], 'radio');
		showsetting('settings_smthumb', 'settingsnew[smthumb]', $settings['smthumb'], 'text');
		showsetting('settings_smcols', 'settingsnew[smcols]', $settings['smcols'], 'text');
		showsetting('settings_smrows', 'settingsnew[smrows]', $settings['smrows'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_stat', 'top', 'settingsubmit');
		showsetting('settings_statstatus', 'settingsnew[statstatus]', $settings['statstatus'], 'radio');
		showsetting('settings_statscachelife', 'settingsnew[statscachelife]', $settings['statscachelife'], 'text');
		showsetting('settings_pvfrequence', 'settingsnew[pvfrequence]', $settings['pvfrequence'], 'text');
		showsetting('settings_oltimespan', 'settingsnew[oltimespan]', $settings['oltimespan'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_mod', 'top', 'settingsubmit');
		showsetting('settings_modworkstatus', 'settingsnew[modworkstatus]', $settings['modworkstatus'], 'radio');
		showsetting('settings_maxmodworksmonths', 'settingsnew[maxmodworksmonths]', $settings['maxmodworksmonths'], 'text');
		showsetting('settings_myfunction_savetime', 'settingsnew[myrecorddays]', $settings['myrecorddays'], 'text');
		showsetting('settings_losslessdel', 'settingsnew[losslessdel]', $settings['losslessdel'], 'text');
		showsetting('settings_modreasons', 'settingsnew[modreasons]', $settings['modreasons'], 'textarea');
		showsetting('settings_bannedmessages', 'settingsnew[bannedmessages]', $settings['bannedmessages'], 'radio');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_other', 'top', '');
		showsetting('settings_rssstatus', 'settingsnew[rssstatus]', $settings['rssstatus'], 'radio');
		showsetting('settings_rssttl', 'settingsnew[rssttl]', $settings['rssttl'], 'text');
		showsetting('settings_csscache', 'settingsnew[allowcsscache]', $settings['allowcsscache'], 'radio');
		showsetting('settings_send_birthday', 'settingsnew[bdaystatus]', $settings['bdaystatus'], 'radio');
		showsetting('settings_debug', 'settingsnew[debug]', $settings['debug'], 'radio');

	} elseif($do == 'credits') {

		showtips('settings_credits_tips');

		if(!empty($projectid)) {
			$query = $db->query("SELECT value FROM {$tablepre}projects WHERE id='$projectid'");
			$settings = @array_merge($settings, unserialize($db->result($query, 0)));
		}

		$projectselect = "<select name=\"projectid\" onchange=\"window.location='admincp.php?action=settings&do=credits&projectid='+this.options[this.options.selectedIndex].value\"><option value=\"0\" selected=\"selected\">".$lang['none']."</option>";
		$query = $db->query("SELECT id, name FROM {$tablepre}projects WHERE type='extcredit'");
		while($project = $db->fetch_array($query)) {
			$projectselect .= "<option value=\"$project[id]\" ".($project['id'] == $projectid ? 'selected="selected"' : NULL).">$project[name]</option>\n";
		}
		$projectselect .= '</select>';

		showtype('settings_credits', 'top');
		showsetting('settings_credits_scheme', '', '', $projectselect);
		echo '</tbody></table><br>';
		echo '<script>
			function switchpolicy(obj, col) {
				var status = !obj.checked;
				$("policy" + col).disabled = status;
				var policytable = $("policytable");
				for(var row=2; row<14; row++) {
					if(is_opera) {
						policytable.rows[row].cells[col].firstChild.disabled = true;
					} else {
						policytable.rows[row].cells[col].disabled = status;
					}
				}
			}
		</script>';
		echo '<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">'.
			'<tr class="header"><td colspan="9">'.$lang['settings_credits_extended'].'</td></tr>'.
			'<tr align="center" class="category"><td>'.$lang['credits_id'].'</td><td>'.$lang['credits_title'].'</td><td>'.$lang['credits_unit'].'</td><td>'.$lang['settings_credits_ratio'].'</td><td>'.$lang['settings_credits_init'].'</td><td>'.$lang['settings_credits_available'].'</td><td>'.$lang['settings_credits_show_in_thread'].'</td><td>'.$lang['credits_inport'].'</td><td>'.$lang['credits_import'].'</td></tr>';
		$settings['extcredits'] = unserialize($settings['extcredits']);
		$settings['initcredits'] = explode(',', $settings['initcredits']);
		for($i = 1; $i <= 8; $i++) {
			echo "<tr align=\"center\"><td class=\"altbg1\">extcredits$i</td>".
				"<td class=\"altbg2\"><input type=\"text\" size=\"8\" name=\"settingsnew[extcredits][$i][title]\" value=\"{$settings['extcredits'][$i]['title']}\"></td>".
				"<td class=\"altbg1\"><input type=\"text\" size=\"5\" name=\"settingsnew[extcredits][$i][unit]\" value=\"{$settings['extcredits'][$i]['unit']}\"></td>".
				"<td class=\"altbg2\"><input type=\"text\" size=\"3\" name=\"settingsnew[extcredits][$i][ratio]\" value=\"".(float)$settings['extcredits'][$i]['ratio']."\" onkeyup=\"if(this.value != '0' && \$('allowexchangeout$i').checked == false && \$('allowexchangein$i').checked == false) {\$('allowexchangeout$i').checked = true;\$('allowexchangein$i').checked = true;} else if(this.value == '0') {\$('allowexchangeout$i').checked = false;\$('allowexchangein$i').checked = false;}\"></td>".
				"<td class=\"altbg1\"><input type=\"text\" size=\"3\" name=\"settingsnew[initcredits][$i]\" value=\"".intval($settings['initcredits'][$i])."\"></td>".
				"<td class=\"altbg2\"><input class=\"checkbox\" type=\"checkbox\" name=\"settingsnew[extcredits][$i][available]\" value=\"1\" ".($settings['extcredits'][$i]['available'] ? 'checked' : '')." onclick=\"switchpolicy(this, $i)\"></td>".
				"<td class=\"altbg1\"><input class=\"checkbox\" type=\"checkbox\" name=\"settingsnew[extcredits][$i][showinthread]\" value=\"1\" ".($settings['extcredits'][$i]['showinthread'] ? 'checked' : '')."></td>".
				"<td class=\"altbg2\"><input class=\"checkbox\" type=\"checkbox\" size=\"3\" name=\"settingsnew[extcredits][$i][allowexchangeout]\" value=\"1\" ".($settings['extcredits'][$i]['allowexchangeout'] ? 'checked' : '')." id=\"allowexchangeout$i\"></td>".
				"<td class=\"altbg1\"><input class=\"checkbox\" type=\"checkbox\" size=\"3\" name=\"settingsnew[extcredits][$i][allowexchangein]\" value=\"1\" ".($settings['extcredits'][$i]['allowexchangein'] ? 'checked' : '')." id=\"allowexchangein$i\"></td></tr>";
		}
		echo '<tr><td class="altbg1" colspan="9">'.$lang['settings_credits_extended_comment'].'</td></tr>'.
			'</table><br>';

		echo '<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder" id="policytable">'.
			'<tr class="header"><td colspan="11">'.$lang['settings_credits_policy'].'</td></tr>'.'<tr align="center" class="category"><td width="12%">'.$lang['credits_id'].'</td>';
		$settings['creditspolicy'] = unserialize($settings['creditspolicy']);
		for($i = 1; $i <= 8; $i++) {
			echo "<td id=\"policy$i\" ".($settings['extcredits'][$i]['available'] ? '' : 'disabled')."  class=\"category\" align=\"center\"> extcredits$i<br>".($settings['extcredits'][$i]['title'] ? '('.$settings['extcredits'][$i]['title'].')' : '')."</td>";
		}
		echo '<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_post_comment'].'"><td>'.$lang['settings_credits_policy_post'].'</td>'.creditsrow('post').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_reply_comment'].'"><td>'.$lang['settings_credits_policy_reply'].'</td>'.creditsrow('reply').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_digest_comment'].'"><td>'.$lang['settings_credits_policy_digest'].'</td>'.creditsrow('digest').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_post_attach_comment'].'"><td>'.$lang['settings_credits_policy_post_attach'].'</td>'.creditsrow('postattach').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_get_attach_comment'].'"><td>'.$lang['settings_credits_policy_get_attach'].'</td>'.creditsrow('getattach').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_send_pm_comment'].'"><td>'.$lang['settings_credits_policy_send_pm'].'</td>'.creditsrow('pm').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_search_comment'].'"><td>'.$lang['settings_credits_policy_search'].'</td>'.creditsrow('search').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_promotion_visit_comment'].'"><td>'.$lang['settings_credits_policy_promotion_visit'].'</td>'.creditsrow('promotion_visit').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_promotion_register_comment'].'"><td>'.$lang['settings_credits_policy_promotion_register'].'</td>'.creditsrow('promotion_register').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_trade_comment'].'"><td>'.$lang['settings_credits_policy_trade'].'(+)</td>'.creditsrow('tradefinished').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_policy_poll_comment'].'"><td>'.$lang['settings_credits_policy_poll'].'(+)</td>'.creditsrow('votepoll').'</tr>'.
			'<tr align="center" class="altbg1" title="'.$lang['settings_credits_lowerlimit_comment'].'"><td>'.$lang['settings_credits_lowerlimit'].'</td>'.creditsrow('lowerlimit').'</tr>';
		echo '<tr><td class="altbg1" colspan="12">'.$lang['settings_credits_policy_comment'].'</td></tr>'.
			'</table><br>';

		showtype('settings_credits', 'top', 'settingsubmit');
		showsetting('settings_creditsformula', 'settingsnew[creditsformula]', $settings['creditsformula'], 'textarea');

		$creditstrans = '';
		for($i = 0; $i <= 8; $i++) {
			$creditstrans .= '<option value="'.$i.'" '.($i == intval($settings['creditstrans']) ? 'selected' : '').'>'.($i ? 'extcredits'.$i : $lang['none']).'</option>';
		}
		showsetting('settings_creditstrans', '', '', '<select name="settingsnew[creditstrans]">'.$creditstrans.'</select>');
		showsetting('settings_creditstax', 'settingsnew[creditstax]', $settings['creditstax'], 'text');
		showsetting('settings_transfermincredits', 'settingsnew[transfermincredits]', $settings['transfermincredits'], 'text');
		showsetting('settings_exchangemincredits', 'settingsnew[exchangemincredits]', $settings['exchangemincredits'], 'text');
		showsetting('settings_maxincperthread', 'settingsnew[maxincperthread]', $settings['maxincperthread'], 'text');
		showsetting('settings_maxchargespan', 'settingsnew[maxchargespan]', $settings['maxchargespan'], 'text');

		$extbutton = '&nbsp;&nbsp;&nbsp;<input name="projectsave" type="hidden" value="0"><input class="button" type="button" onclick="$(\'settings\').projectsave.value=1;$(\'settings\').settingsubmit.click()" value="'.$lang['saveconf'].'">';

	} elseif($do == 'serveropti') {

		$checkdelayvc = array($settings['delayviewcount'] => 'checked');

		showtips('settings_tips');
		showtype('settings_serveropti', 'top', 'settingsubmit');
		showsetting('settings_gzipcompress', 'settingsnew[gzipcompress]', $settings['gzipcompress'], 'radio');
		showsetting('settings_delayviewcount', '', '', '<input class="radio" type="radio" name="settingsnew[delayviewcount]" value="0" '.$checkdelayvc[0].'>'.$lang['none'].'<br><input class="radio" type="radio" name="settingsnew[delayviewcount]" value="1" '.$checkdelayvc[1].'>'.$lang['settings_delayviewcount_thread'].'<br><input class="radio" type="radio" name="settingsnew[delayviewcount]" value="2" '.$checkdelayvc[2].'>'.$lang['settings_delayviewcount_attach'].'<br><input class="radio" type="radio" name="settingsnew[delayviewcount]" value="3" '.$checkdelayvc[3].'>'.$lang['settings_delayviewcount_thread_attach']);
		showsetting('settings_nocacheheaders', 'settingsnew[nocacheheaders]', $settings['nocacheheaders'], 'radio');
		showsetting('settings_transsidstatus', 'settingsnew[transsidstatus]', $settings['transsidstatus'], 'radio');
		showsetting('settings_maxonlines', 'settingsnew[maxonlines]', $settings['maxonlines'], 'text');
		showsetting('settings_onlinehold', 'settingsnew[onlinehold]', $settings['onlinehold'], 'text');
		showsetting('settings_loadctrl', 'settingsnew[loadctrl]', $settings['loadctrl'], 'text');
		showsetting('settings_floodctrl', 'settingsnew[floodctrl]', $settings['floodctrl'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_search', 'top', 'settingsubmit');
		showsetting('settings_searchctrl', 'settingsnew[searchctrl]', $settings['searchctrl'], 'text');
		showsetting('settings_maxspm', 'settingsnew[maxspm]', $settings['maxspm'], 'text');
		showsetting('settings_maxsearchresults', 'settingsnew[maxsearchresults]', $settings['maxsearchresults'], 'text');

	} elseif($do == 'seccode') {

		$checksc = array();
		$settings['seccodestatus'] = sprintf('%05b', $settings['seccodestatus']);
		for($i = 1; $i <= 5; $i++) {
			$checksc[$i] = $settings['seccodestatus'][5 - $i] ? 'checked' : '';
		}
		$settings['seccodedata'] = unserialize($settings['seccodedata']);

		showtips('settings_seccode_tips');
		showtype('settings_seccode', 'top', 'settingsubmit');
		showsetting('settings_seccodestatus', '', '', '<input class="checkbox" type="checkbox" name="settingsnew[seccodestatus][1]" value="1" '.$checksc[1].'> '.$lang['settings_seccodestatus_register'].'<br><input class="checkbox" type="checkbox" name="settingsnew[seccodestatus][2]" value="1" '.$checksc[2].'> '.$lang['settings_seccodestatus_login'].'<br><input class="checkbox" type="checkbox" name="settingsnew[seccodestatus][3]" value="1" '.$checksc[3].'> '.$lang['settings_seccodestatus_post'].'<br><input class="checkbox" type="checkbox" name="settingsnew[seccodestatus][4]" value="1" '.$checksc[4].'> '.$lang['settings_seccodestatus_sendpm'].'<br><input class="checkbox" type="checkbox" name="settingsnew[seccodestatus][5]" value="1" '.$checksc[5].'> '.$lang['settings_seccodestatus_profile']);
		showsetting('settings_seccodeloginfailedcount', 'settingsnew[seccodedata][loginfailedcount]', $settings['seccodedata']['loginfailedcount'], 'radio');
		showsetting('settings_seccodeanimator', 'settingsnew[seccodedata][animator]', $settings['seccodedata']['animator'], 'radio');
		showsetting('settings_seccodettf', 'settingsnew[seccodedata][ttf]', $settings['seccodedata']['ttf'], 'radio');
		showsetting('settings_seccodebackground', 'settingsnew[seccodedata][background]', $settings['seccodedata']['background'], 'radio');
		showsetting('settings_seccodewidth', 'settingsnew[seccodedata][width]', $settings['seccodedata']['width'], 'text');
		showsetting('settings_seccodeheight', 'settingsnew[seccodedata][height]', $settings['seccodedata']['height'], 'text');

	} elseif($do == 'secqaa') {

		$settings['secqaa'] = unserialize($settings['secqaa']);
		$checksq = array();
		$settings['secqaa']['status'] = sprintf('%03b',$settings['secqaa']['status']);
		for($i = 1; $i <= 3; $i++) {
			$checksq[$i] = $settings['secqaa']['status']{$i - 1} ? 'checked' : '';
		}

		$page = max(1, intval($page));
		$start_limit = ($page - 1) * 10;
		$query = $db->query("SELECT COUNT(*) FROM {$tablepre}itempool");
		$secqaanums = $db->result($query, 0);
		$multipage = multi($secqaanums, 10, $page, 'admincp.php?action=settings&do=secqaa');

		$query = $db->query("SELECT * FROM {$tablepre}itempool LIMIT $start_limit, 10");
		$secqaa = '';
		while($item = $db->fetch_array($query)) {
			$secqaa .= '<tr align="center"><td class="altbg1" ><input class="checkbox" type="checkbox" name="delete[]" value="'.$item['id'].'"></td><td class="altbg1"><textarea name="question['.$item['id'].']" rows="3" cols="60">'.dhtmlspecialchars($item['question']).'</textarea></td><td class="altbg2"><input type="text" name="answer['.$item['id'].']" size="30" maxlength="50" value="'.$item['answer'].'"></td></tr>';
		}

		showtips('settings_secqaa_tips');
		showtype('settings_secqaa', 'top', 'settingsubmit');
		showsetting('settings_secqaa_status', '', '', '<input class="checkbox" type="checkbox" name="settingsnew[secqaa][status][1]" value="1" '.$checksq[1].'> '.$lang['settings_seccodestatus_register'].'<br><input class="checkbox" type="checkbox" name="settingsnew[secqaa][status][2]" value="1" '.$checksq[2].'> '.$lang['settings_seccodestatus_post'].'<br><input class="checkbox" type="checkbox" name="settingsnew[secqaa][status][3]" value="1" '.$checksq[3].'> '.$lang['settings_seccodestatus_sendpm']);
		showsetting('settings_secqaa_minposts', 'settingsnew[secqaa][minposts]', $settings['secqaa']['minposts'], 'text');

		echo '</table><br><table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">'.
			'<tr class="header"><td colspan="3">'.$lang['settings_secqaa_qaa'].'</td></tr>';
		echo '<tr class="category"><td><input class="checkbox" type="checkbox" name="chkall" onclick="checkall(this.form, \'delete\')">'.$lang['del'].'</td><td>'.$lang['settings_secqaa_question'].'</td><td>'.$lang['settings_secqaa_answer'].'</td></tr>'.
			$secqaa.($multipage ? '<tr><td colspan=5>'.$multipage.'</td></tr>' : '').'<tbody id="secqaabody"><tr align="center"><td class="altbg1">'.$lang['add_new'].'<a href="###" onclick="newnode = $(\'secqaabodyhidden\').firstChild.cloneNode(true); $(\'secqaabody\').appendChild(newnode)">[+]</a></td><td class="altbg1"><textarea name="newquestion[]" rows="3" cols="60"></textarea></td><td class="altbg2"><input type="text" name="newanswer[]" size="30" maxlength="50"></td></tr></tbody><tbody id="secqaabodyhidden" style="display:none"><tr align="center"><td class="altbg1"></td><td class="altbg1"><textarea name="newquestion[]" rows="3" cols="60"></textarea></td><td class="altbg2"><input type="text" name="newanswer[]" size="30" maxlength="50"></td></tr></tbody>';

		echo '<tr><td colspan=3>'.$lang['settings_secqaa_comment'].'</td></tr></table>';

	} elseif($do == 'datetime') {

		$checktimeformat = array($settings['timeformat'] == 'H:i' ? 24 : 12 => 'checked');
		$settings['dateformat'] = str_replace('n', 'mm', $settings['dateformat']);
		$settings['dateformat'] = str_replace('j', 'dd', $settings['dateformat']);
		$settings['dateformat'] = str_replace('y', 'yy', $settings['dateformat']);
		$settings['dateformat'] = str_replace('Y', 'yyyy', $settings['dateformat']);

		showtype('settings_subtitle_datetime', 'top', 'settingsubmit');
		showsetting('settings_dateformat', 'settingsnew[dateformat]', $settings['dateformat'], 'text');
		showsetting('settings_timeformat', '', '', '<input class="radio" type="radio" name="settingsnew[timeformat]" value="24" '.$checktimeformat[24].'> 24 Hour <input class="radio" type="radio" name="settingsnew[timeformat]" value="12" '.$checktimeformat[12].'> 12 Hour');
		showsetting('settings_timeoffset', 'settingsnew[timeoffset]', $settings['timeoffset'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_periods', 'top', 'settingsubmit');
		showsetting('settings_visitbanperiods', 'settingsnew[visitbanperiods]', $settings['visitbanperiods'], 'textarea');
		showsetting('settings_postbanperiods', 'settingsnew[postbanperiods]', $settings['postbanperiods'], 'textarea');
		showsetting('settings_postmodperiods', 'settingsnew[postmodperiods]', $settings['postmodperiods'], 'textarea');
		showsetting('settings_ban_downtime', 'settingsnew[attachbanperiods]', $settings['attachbanperiods'], 'textarea');
		showsetting('settings_searchbanperiods', 'settingsnew[searchbanperiods]', $settings['searchbanperiods'], 'textarea');

	} elseif($do == 'permissions') {

		$checkreport = array($settings['reportpost'] => 'checked');

		showtype('settings_permissions', 'top', 'settingsubmit');
		showsetting('settings_memliststatus', 'settingsnew[memliststatus]', $settings['memliststatus'], 'radio');
		showsetting('settings_reportpost', '', '', '<input class="radio" type="radio" name="settingsnew[reportpost]" value="0" '.$checkreport[0].'> '.$lang['settings_reportpost_none'].'<br><input class="radio" type="radio" name="settingsnew[reportpost]" value="1" '.$checkreport[1].'> '.$lang['settings_reportpost_level_1'].'<br><input class="radio" type="radio" name="settingsnew[reportpost]" value="2" '.$checkreport[2].'> '.$lang['settings_reportpost_level_2'].'<br><input class="radio" type="radio" name="settingsnew[reportpost]" value="3" '.$checkreport[3].'> '.$lang['settings_reportpost_level_3']);
		showsetting('settings_minpostsize', 'settingsnew[minpostsize]', $settings['minpostsize'], 'text');
		showsetting('settings_maxpostsize', 'settingsnew[maxpostsize]', $settings['maxpostsize'], 'text');
		showsetting('settings_favorite_storage', 'settingsnew[maxfavorites]', $settings['maxfavorites'], 'text');
		showsetting('settings_subscriptions', 'settingsnew[maxsubscriptions]', $settings['maxsubscriptions'], 'text');
		showsetting('settings_maxavatarsize', 'settingsnew[maxavatarsize]', $settings['maxavatarsize'], 'text');
		showsetting('settings_maxavatarpixel', 'settingsnew[maxavatarpixel]', $settings['maxavatarpixel'], 'text');
		showsetting('settings_maxpolloptions', 'settingsnew[maxpolloptions]', $settings['maxpolloptions'], 'text');
		showsetting('settings_edittimelimit', 'settingsnew[edittimelimit]', $settings['edittimelimit'], 'text');
		showsetting('settings_editby', 'settingsnew[editedby]', $settings['editedby'], 'radio');
		echo '</tbody></table><br>';

		showtype('settings_subtitle_rate', 'top', 'settingsubmit');
		showsetting('settings_karmaratelimit', 'settingsnew[karmaratelimit]', $settings['karmaratelimit'], 'text');
		showsetting('settings_modratelimit', 'settingsnew[modratelimit]', $settings['modratelimit'], 'radio');
		showsetting('settings_dupkarmarate', 'settingsnew[dupkarmarate]', $settings['dupkarmarate'], 'radio');

	} elseif($do == 'attachments') {

		$checkattach = array($settings['attachsave'] => 'checked');
		$checkwm = array($settings['watermarkstatus'] => 'checked');
		$checkwatermarktype = array($settings['watermarktype'] => 'checked');

		showtype('settings_attachments', 'top', 'settingsubmit');
		showsetting('settings_attachdir', 'settingsnew[attachdir]', $settings['attachdir'], 'text');
		showsetting('settings_attachurl', 'settingsnew[attachurl]', $settings['attachurl'], 'text');
		showsetting('settings_attachimgpost', 'settingsnew[attachimgpost]', $settings['attachimgpost'], 'radio');
		showsetting('settings_attachrefcheck', 'settingsnew[attachrefcheck]', $settings['attachrefcheck'], 'radio');
		showsetting('settings_attachsave', '', '', '<input class="radio" type="radio" name="settingsnew[attachsave]" value="0" '.$checkattach[0].'> '.$lang['settings_attachsave_default'].'<br><input class="radio" type="radio" name="settingsnew[attachsave]" value="1" '.$checkattach[1].'> '.$lang['settings_attachsave_forum'].'<br><input class="radio" type="radio" name="settingsnew[attachsave]" value="2" '.$checkattach[2].'> '.$lang['settings_attachsave_type'].'<br><input class="radio" type="radio" name="settingsnew[attachsave]" value="3" '.$checkattach[3].'> '.$lang['settings_attachsave_month'].'<br><input class="radio" type="radio" name="settingsnew[attachsave]" value="4" '.$checkattach[4].'> '.$lang['settings_attachsave_day']);
		showsetting('settings_thumbstatus', 'settingsnew[thumbstatus]', $settings['thumbstatus'], 'radio');
		showsetting('settings_thumbwidth', 'settingsnew[thumbwidth]', $settings['thumbwidth'], 'text');
		showsetting('settings_thumbheight', 'settingsnew[thumbheight]', $settings['thumbheight'], 'text');
		showsetting('settings_watermarkstatus', '', '', '<table cellspacing="'.INNERBORDERWIDTH.'" cellpadding="'.TABLESPACE.'" class="tableborder" style="margin-bottom: 3px; margin-top:3px;"><tr><td colspan="3"><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="0" '.$checkwm[0].'>'.$lang['settings_watermarkstatus_none'].'</td></tr><tr align="center" class="altbg2"><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="1" '.$checkwm[1].'> #1</td><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="2" '.$checkwm[2].'> #2</td><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="3" '.$checkwm[3].'> #3</td></tr><tr align="center" class="altbg2"><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="4" '.$checkwm[4].'> #4</td><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="5" '.$checkwm[5].'> #5</td><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="6" '.$checkwm[6].'> #6</td></tr><tr align="center" class="altbg2"><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="7" '.$checkwm[7].'> #7</td><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="8" '.$checkwm[8].'> #8</td><td><input class="radio" type="radio" name="settingsnew[watermarkstatus]" value="9" '.$checkwm[9].'> #9</td></tr></table>');
		showsetting('settings_watermarktype', '', '', '<input class="radio" type="radio" name="settingsnew[watermarktype]" value="0" '.$checkwatermarktype[0].'> '.$lang['settings_watermarktype_gif'].'<br><input class="radio" type="radio" name="settingsnew[watermarktype]" value="1" '.$checkwatermarktype[1].'> '.$lang['settings_watermarktype_png']);
		showsetting('settings_watermarktrans', 'settingsnew[watermarktrans]', $settings['watermarktrans'], 'text');
		showsetting('settings_watermarkquality', 'settingsnew[watermarkquality]', $settings['watermarkquality'], 'text');

		if($isfounder) {
			$settings['ftp']['password'] = $settings['ftp']['password'] ? $settings['ftp']['password']{0}.'********'.$settings['ftp']['password']{strlen($settings['ftp']['password']) - 1} : '';
			echo '</tbody></table><br>';
			showtype('settings_remote', 'top', 'settingsubmit');
			showsetting('settings_remote_enabled', 'settingsnew[ftp][on]', $settings['ftp']['on'], 'radio');
			showsetting('settings_remote_enabled_ssl', 'settingsnew[ftp][ssl]', $settings['ftp']['ssl'], 'radio');
			showsetting('settings_remote_ftp_host', 'settingsnew[ftp][host]', $settings['ftp']['host'], 'text');
			showsetting('settings_remote_ftp_port', 'settingsnew[ftp][port]', $settings['ftp']['port'], 'text');
			showsetting('settings_remote_ftp_user', 'settingsnew[ftp][username]', $settings['ftp']['username'], 'text');
			showsetting('settings_remote_ftp_pass', 'settingsnew[ftp][password]', $settings['ftp']['password'], 'text');
			showsetting('settings_remote_ftp_pasv', 'settingsnew[ftp][pasv]', $settings['ftp']['pasv'], 'radio');
			showsetting('settings_remote_dir', 'settingsnew[ftp][attachdir]', $settings['ftp']['attachdir'], 'text');
			showsetting('settings_remote_url', 'settingsnew[ftp][attachurl]', $settings['ftp']['attachurl'], 'text');
			showsetting('settings_remote_hide_dir', 'settingsnew[ftp][hideurl]', $settings['ftp']['hideurl'], 'radio');
			showsetting('settings_remote_timeout', 'settingsnew[ftp][timeout]', $settings['ftp']['timeout'], 'text');
			$extbutton = '&nbsp;&nbsp;&nbsp;<input class="button" type="submit" name="ftpcheck" value="'.$lang['settings_remote_ftpcheck'].'" onclick="this.form.action=\'admincp.php?action=ftpcheck\';this.form.target=\'ftpcheckiframe\'">';
		}

	} elseif($do == 'javascript') {

		$settings['jsdateformat'] = str_replace('n', 'mm', $settings['jsdateformat']);
		$settings['jsdateformat'] = str_replace('j', 'dd', $settings['jsdateformat']);
		$settings['jsdateformat'] = str_replace('y', 'yy', $settings['jsdateformat']);
		$settings['jsdateformat'] = str_replace('Y', 'yyyy', $settings['jsdateformat']);

		showtype('settings_javascript', 'top', 'settingsubmit');
		showsetting('settings_jsstatus', 'settingsnew[jsstatus]', $settings['jsstatus'], 'radio');
		showsetting('settings_jscachelife', 'settingsnew[jscachelife]', $settings['jscachelife'], 'text');
		showsetting('settings_jsdateformat', 'settingsnew[jsdateformat]', $settings['jsdateformat'], 'text');
		showsetting('settings_jsrefdomains', 'settingsnew[jsrefdomains]', $settings['jsrefdomains'], 'textarea');

	} elseif($do == 'wap') {

		$checkwapcharset = array($settings['wapcharset'] => 'checked');
		$settings['wapdateformat'] = str_replace('n', 'mm', $settings['wapdateformat']);
		$settings['wapdateformat'] = str_replace('j', 'dd', $settings['wapdateformat']);
		$settings['wapdateformat'] = str_replace('y', 'yy', $settings['wapdateformat']);
		$settings['wapdateformat'] = str_replace('Y', 'yyyy', $settings['wapdateformat']);

		showtype('settings_wap', 'top', 'settingsubmit');
		showsetting('settings_wapstatus', 'settingsnew[wapstatus]', $settings['wapstatus'], 'radio');
		showsetting('settings_wap_register', 'settingsnew[wapregister]', $settings['wapregister'], 'radio');
		showsetting('settings_wapcharset', '', '', '<input class="radio" type="radio" name="settingsnew[wapcharset]" value="1" '.$checkwapcharset[1].'> UTF-8 <input class="radio" type="radio" name="settingsnew[wapcharset]" value="2" '.$checkwapcharset[2].'> UNICODE');
		showsetting('settings_waptpp', 'settingsnew[waptpp]', $settings['waptpp'], 'text');
		showsetting('settings_wapppp', 'settingsnew[wapppp]', $settings['wapppp'], 'text');
		showsetting('settings_wapdateformat', 'settingsnew[wapdateformat]', $settings['wapdateformat'], 'text');
		showsetting('settings_wapmps', 'settingsnew[wapmps]', $settings['wapmps'], 'text');

	} elseif($do == 'space') {

		showtype('settings_space', 'top', 'settingsubmit');
		showsetting('settings_spacestatus', 'settingsnew[spacestatus]', $settings['spacestatus'], 'radio');
		showsetting('settings_spacecachelife', 'settingsnew[spacecachelife]', $settings['spacecachelife'], 'text');
		showsetting('settings_spacelimitmythreads', 'settingsnew[spacelimitmythreads]', $settings['spacelimitmythreads'], 'text');
		showsetting('settings_spacelimitmyreplies', 'settingsnew[spacelimitmyreplies]', $settings['spacelimitmyreplies'], 'text');
		showsetting('settings_spacelimitmyrewards', 'settingsnew[spacelimitmyrewards]', $settings['spacelimitmyrewards'], 'text');
		showsetting('settings_spacelimitmytrades', 'settingsnew[spacelimitmytrades]', $settings['spacelimitmytrades'], 'text');
		showsetting('settings_spacelimitmyblogs', 'settingsnew[spacelimitmyblogs]', $settings['spacelimitmyblogs'], 'text');
		showsetting('settings_spacelimitmyfriends', 'settingsnew[spacelimitmyfriends]', $settings['spacelimitmyfriends'], 'text');
		showsetting('settings_spacelimitmyfavforums', 'settingsnew[spacelimitmyfavforums]', $settings['spacelimitmyfavforums'], 'text');
		showsetting('settings_spacelimitmyfavthreads', 'settingsnew[spacelimitmyfavthreads]', $settings['spacelimitmyfavthreads'], 'text');
		showsetting('settings_spacetextlength', 'settingsnew[spacetextlength]', $settings['spacetextlength'], 'text');

	} elseif($do == 'cachethread') {

		include_once DISCUZ_ROOT.'./include/forum.func.php';
		$forumselect = '<select name="fids[]" multiple="multiple" style="width: 70%" size="10"><option value="all">'.$lang['all_forum'].'</option><option value="">&nbsp;</option>'.forumselect().'</select>';
		showtype('settings_cachethread', 'top', 'settingsubmit');
		showsetting('settings_cachethread_indexlife', 'settingsnew[cacheindexlife]', $settings['cacheindexlife'], 'text');
		showsetting('settings_cachethread_life', 'settingsnew[cachethreadlife]', $settings['cachethreadlife'], 'text');
		showsetting('settings_cachethread_dir', 'settingsnew[cachethreaddir]', $settings['cachethreaddir'], 'text');
		echo '</tbody></table><br>';

		showtype('settings_cachethread_coefficient_set', 'top', 'settingsubmit');
		showsetting('settings_cachethread_coefficient', 'settingsnew[threadcaches]', '', "<input type=\"text\" size=\"30\" name=\"settingsnew[threadcaches]\" value=\"\">");
		showsetting('settings_cachethread_coefficient_forum', '', '', $forumselect);

	} else {

		$do = 'basic';
		showtype('settings_general', 'top');
		showsetting('settings_bbname', 'settingsnew[bbname]', $settings['bbname'], 'text');
		showsetting('settings_sitename', 'settingsnew[sitename]', $settings['sitename'], 'text');
		showsetting('settings_siteurl', 'settingsnew[siteurl]', $settings['siteurl'], 'text');
		showsetting('settings_index_name', 'settingsnew[indexname]', $settings['indexname'], 'text');
		showsetting('settings_icp', 'settingsnew[icp]', $settings['icp'], 'text');
		showsetting('settings_boardlicensed', 'settingsnew[boardlicensed]', $settings['boardlicensed'], 'radio');
		showsetting('settings_bbclosed', 'settingsnew[bbclosed]', $settings['bbclosed'], 'radio');
		showsetting('settings_closedreason', 'settingsnew[closedreason]', $settings['closedreason'], 'textarea');
	}
	showtype('', 'bottom');

	echo '<br><center><input class="button" type="submit" name="settingsubmit" value="'.$lang['submit'].'">'.$extbutton.'</center></form><iframe name="ftpcheckiframe" style="display: none"></iframe>';

} else {

	if(isset($settingsnew['bbname'])) {
		$settingsnew['bbname'] = dhtmlspecialchars($settingsnew['bbname']);
	}

	if(isset($settingsnew['censoruser'])) {
		$settingsnew['censoruser'] = trim(preg_replace("/\s*(\r\n|\n\r|\n|\r)\s*/", "\r\n", $settingsnew['censoruser']));
	}

	if(isset($settingsnew['censoremail'])) {
		$settingsnew['censoremail'] = trim(preg_replace("/\s*(\r\n|\n\r|\n|\r)\s*/", "\r\n", $settingsnew['censoremail']));
	}

	if(isset($settingsnew['ipregctrl'])) {
		$settingsnew['ipregctrl'] = trim(preg_replace("/\s*(\r\n|\n\r|\n|\r)\s*/", "\r\n", $settingsnew['ipregctrl']));
	}

	if(isset($settingsnew['ipaccess'])) {
		if($settingsnew['ipaccess'] = trim(preg_replace("/(\s*(\r\n|\n\r|\n|\r)\s*)/", "\r\n", $settingsnew['ipaccess']))) {
			if(!ipaccess($onlineip, $settingsnew['ipaccess'])) {
				cpmsg('settings_ipaccess_invalid');
			}
		}
	}

	if(isset($settingsnew['adminipaccess'])) {
		if($settingsnew['adminipaccess'] = trim(preg_replace("/(\s*(\r\n|\n\r|\n|\r)\s*)/", "\r\n", $settingsnew['adminipaccess']))) {
			if(!ipaccess($onlineip, $settingsnew['adminipaccess'])) {
				cpmsg('settings_adminipaccess_invalid');
			}
		}
	}

	if(isset($settingsnew['welcomemsgtitle'])) {
		$settingsnew['welcomemsgtitle'] = cutstr(trim(dhtmlspecialchars($settingsnew['welcomemsgtitle'])), 75);
	}

	if(isset($settingsnew['showsignatures']) && isset($settingsnew['showavatars']) && isset($settingsnew['showimages'])) {
		$settingsnew['showsettings'] = bindec($settingsnew['showsignatures'].$settingsnew['showavatars'].$settingsnew['showimages']);
	}

	if(!empty($settingsnew['globalstick'])) {
		updatecache('globalstick');
	}

	if($do == 'functions') {
		$jsmenumax = is_array($settingsnew['jsmenustatus']) ? max(array_keys($settingsnew['jsmenustatus'])) : 0;
		$jsmenustatus = '';
		for($i = $jsmenumax; $i > 0; $i --) {
			$jsmenustatus .= intval($settingsnew['jsmenustatus'][$i]);
		}
		$settingsnew['jsmenustatus'] = bindec($jsmenustatus);
		$settingsnew['smthumb'] = intval($settingsnew['smthumb']) >= 20 && intval($settingsnew['smthumb']) <= 40 ? intval($settingsnew['smthumb']) : 20;
	}

	if(isset($settingsnew['defaulteditormode']) && isset($settingsnew['allowswitcheditor'])) {
		$settingsnew['editoroptions'] = bindec($settingsnew['defaulteditormode'].$settingsnew['allowswitcheditor']);
	}

	if(isset($settingsnew['myrecorddays'])) {
		$settingsnew['myrecorddays'] = intval($settingsnew['myrecorddays']) > 0 ? intval($settingsnew['myrecorddays']) : 30;
	}

	if(!empty($settingsnew['thumbstatus']) && !function_exists('imagejpeg')) {
		$settingsnew['thumbstatus'] = 0;
	}

	if(isset($settingsnew['creditsformula']) && isset($settingsnew['extcredits']) && isset($settingsnew['creditspolicy']) && isset($settingsnew['initcredits']) && isset($settingsnew['creditstrans']) && isset($settingsnew['creditstax'])) {
		if(!preg_match("/^([\+\-\*\/\.\d\(\)]|((extcredits[1-8]|digestposts|posts|pageviews|oltime)([\+\-\*\/\(\)]|$)+))+$/", $settingsnew['creditsformula']) || !is_null(@eval(preg_replace("/(digestposts|posts|pageviews|oltime|extcredits[1-8])/", "\$\\1", $settingsnew['creditsformula']).';'))) {
			cpmsg('settings_creditsformula_invalid');
		}

		$extcreditsarray = array();
		if(is_array($settingsnew['extcredits'])) {
			foreach($settingsnew['extcredits'] as $key => $value) {
				if($value['available'] && !$value['title']) {
					cpmsg('settings_credits_title_invalid');
				}
				$extcreditsarray[$key] = array
					(
					'title'	=> dhtmlspecialchars(stripslashes($value['title'])),
					'unit' => dhtmlspecialchars(stripslashes($value['unit'])),
					'ratio' => ($value['ratio'] > 0 ? (float)$value['ratio'] : 0),
					'available' => $value['available'],
					'lowerlimit' => intval($settingsnew['creditspolicy']['lowerlimit'][$key]),
					'showinthread' => $value['showinthread'],
					'allowexchangein' => $value['allowexchangein'],
					'allowexchangeout' => $value['allowexchangeout']
					);
				$settingsnew['initcredits'][$key] = intval($settingsnew['initcredits'][$key]);
			}
		}
		if(is_array($settingsnew['creditspolicy'])) {
			foreach($settingsnew['creditspolicy'] as $key => $value) {
				for($i = 1; $i <= 8; $i++) {
					if(empty($value[$i])) {
						unset($settingsnew['creditspolicy'][$key][$i]);
					} else {
						$value[$i] = $value[$i] > 99 ? 99 : ($value[$i] < -99 ? -99 : $value[$i]);
						$settingsnew['creditspolicy'][$key][$i] = intval($value[$i]);
					}
				}
			}
		} else {
			$settingsnew['creditspolicy'] = array();
		}

		if($settingsnew['creditstrans'] && empty($settingsnew['extcredits'][$settingsnew['creditstrans']]['available'])) {
			cpmsg('settings_creditstrans_invalid');
		}
		$settingsnew['creditspolicy'] = addslashes(serialize($settingsnew['creditspolicy']));

		$settingsnew['creditsformulaexp'] = $settingsnew['creditsformula'];
		foreach(array('digestposts', 'posts', 'oltime', 'pageviews', 'extcredits1', 'extcredits2', 'extcredits3', 'extcredits4', 'extcredits5', 'extcredits6', 'extcredits7', 'extcredits8') as $var) {
			if($extcreditsarray[$creditsid = preg_replace("/^extcredits(\d{1})$/", "\\1", $var)]['available']) {
				$replacement = $extcreditsarray[$creditsid]['title'];
			} else {
				$replacement = $lang['settings_creditsformula_'.$var];
			}
			$settingsnew['creditsformulaexp'] = str_replace($var, '<u>'.$replacement.'</u>', $settingsnew['creditsformulaexp']);
		}
		$settingsnew['creditsformulaexp'] = addslashes('<u>'.$lang['settings_creditsformula_credits'].'</u>='.$settingsnew['creditsformulaexp']);

		$initformula = str_replace('posts', '0', $settingsnew['creditsformula']);
		for($i = 1; $i <= 8; $i++) {
			$initformula = str_replace('extcredits'.$i, $settingsnew['initcredits'][$i], $initformula);
		}
		eval("\$initcredits = round($initformula);");

		$settingsnew['extcredits'] = addslashes(serialize($extcreditsarray));
		$settingsnew['initcredits'] = $initcredits.','.implode(',', $settingsnew['initcredits']);
		if($settingsnew['creditstax'] < 0 || $settingsnew['creditstax'] >= 1) {
			$settingsnew['creditstax'] = 0;
		}
	}

	if(isset($settingsnew['gzipcompress'])) {
		if(!function_exists('ob_gzhandler') && $settingsnew['gzipcompress']) {
			cpmsg('settings_gzip_invalid');
		}
	}

	if(isset($settingsnew['maxonlines'])) {
		if($settingsnew['maxonlines'] > 65535 || !is_numeric($settingsnew['maxonlines'])) {
			cpmsg('settings_maxonlines_invalid');
		}

		$db->query("ALTER TABLE {$tablepre}sessions MAX_ROWS=$settingsnew[maxonlines]");
		if($settingsnew['maxonlines'] < $settings['maxonlines']) {
			$db->query("DELETE FROM {$tablepre}sessions");
		}
	}

	if(isset($settingsnew['seccodedata'])) {
		$settingsnew['seccodedata']['width'] = intval($settingsnew['seccodedata']['width']);
		$settingsnew['seccodedata']['height'] = intval($settingsnew['seccodedata']['height']);
		if($settingsnew['seccodedata']['width'] < 70 || $settingsnew['seccodedata']['width'] > 140 || $settingsnew['seccodedata']['height'] < 25 || $settingsnew['seccodedata']['height'] > 50) {
			cpmsg('settings_seccodewidthheight_invalid');
		}

		$settingsnew['seccodedata']['loginfailedcount'] = !empty($settingsnew['seccodedata']['loginfailedcount']) ? 3 : 0;
		$settingsnew['seccodedata'] = addslashes(serialize($settingsnew['seccodedata']));
	}

	if($do == 'seccode' || isset($settingsnew['seccodestatus'])) {
		$settingsnew['seccodestatus'] = bindec(intval($settingsnew['seccodestatus'][5]).intval($settingsnew['seccodestatus'][4]).intval($settingsnew['seccodestatus'][3]).intval($settingsnew['seccodestatus'][2]).intval($settingsnew['seccodestatus'][1]));
	}

	if($do == 'secqaa') {
		if(is_array($delete)) {
			$db->query("DELETE FROM	{$tablepre}itempool WHERE id IN (".implodeids($delete).")");
		}

		if(is_array($question)) {
			foreach($question AS $key => $q) {
				$q = trim($q);
				$a = cutstr(dhtmlspecialchars(trim($answer[$key])), 50);
				if($q && $a) {
					$db->query("UPDATE {$tablepre}itempool SET question='$q', answer='$a' WHERE id='$key'");
				}
			}
		}

		if(is_array($newquestion) && is_array($newanswer)) {
			foreach($newquestion AS $key => $q) {
				$q = trim($q);
				$a = cutstr(dhtmlspecialchars(trim($newanswer[$key])), 50);
				if($q && $a) {
					$db->query("INSERT INTO	{$tablepre}itempool (question, answer) VALUES ('$q', '$a')");
				}
			}
		}

		updatecache('secqaa');

		$settingsnew['secqaa']['status'] = bindec(intval($settingsnew['secqaa']['status'][1]).intval($settingsnew['secqaa']['status'][2]).intval($settingsnew['secqaa']['status'][3]));
		$lackofqaa = 0;
		if($settingsnew['secqaa']['status']) {
			$query = $db->query("SELECT COUNT(*) FROM {$tablepre}itempool");
			if($db->result($query, 0) < 10) {
				$settingsnew['secqaa']['status'] = 0;
				$lackofqaa = 1;
			}
		}

		$settingsnew['secqaa'] = serialize($settingsnew['secqaa']);

	}

	if(isset($settingsnew['visitbanperiods']) && isset($settingsnew['postbanperiods']) && isset($settingsnew['postmodperiods']) && isset($settingsnew['searchbanperiods'])) {
		foreach(array('visitbanperiods', 'postbanperiods', 'postmodperiods', 'searchbanperiods') as $periods) {
			$periodarray = array();
			foreach(explode("\n", $settingsnew[$periods]) as $period) {
				if(preg_match("/^\d{1,2}\:\d{2}\-\d{1,2}\:\d{2}$/", $period = trim($period))) {
					$periodarray[] = $period;
				}
			}
			$settingsnew[$periods] = implode("\r\n", $periodarray);
		}
	}

	if(isset($settingsnew['timeformat'])) {
		$settingsnew['timeformat'] = $settingsnew['timeformat'] == '24' ? 'H:i' : 'h:i A';
	}

	if(isset($settingsnew['dateformat'])) {
		$settingsnew['dateformat'] = str_replace('mm', 'n', $settingsnew['dateformat']);
		$settingsnew['dateformat'] = str_replace('dd', 'j', $settingsnew['dateformat']);
		$settingsnew['dateformat'] = str_replace('yyyy', 'Y', $settingsnew['dateformat']);
		$settingsnew['dateformat'] = str_replace('yy', 'y', $settingsnew['dateformat']);
	}

	if($isfounder && isset($settingsnew['ftp'])) {
		if(!empty($settingsnew['ftp']['password'])) {
			$pwlen = strlen($settingsnew['ftp']['password']);
			if($pwlen < 3) {
				cpmsg('ftp_password_short');
			}
			if($settingsnew['ftp']['password']{0} == $settings['ftp']['password']{0} && $settingsnew['ftp']['password']{$pwlen - 1} == $settings['ftp']['password']{strlen($settings['ftp']['password']) - 1} && substr($settingsnew['ftp']['password'], 1, $pwlen - 2) == '********') {
				$settingsnew['ftp']['password'] = $settings['ftp']['password'];
			}
			$settingsnew['ftp']['password'] = authcode($settingsnew['ftp']['password'], 'ENCODE', md5($authkey));
		}
		$settingsnew['ftp'] = serialize($settingsnew['ftp']);
	} else {
		$settings['ftp']['password'] = authcode($settings['ftp']['password'], 'ENCODE', md5($authkey));
		$settingsnew['ftp'] = serialize($settings['ftp']);
	}

	if(isset($settingsnew['jsrefdomains'])) {
		$settingsnew['jsrefdomains'] = trim(preg_replace("/(\s*(\r\n|\n\r|\n|\r)\s*)/", "\r\n", $settingsnew['jsrefdomains']));
	}

	if(isset($settingsnew['jsdateformat'])) {
		$settingsnew['jsdateformat'] = str_replace('mm', 'n', $settingsnew['jsdateformat']);
		$settingsnew['jsdateformat'] = str_replace('dd', 'j', $settingsnew['jsdateformat']);
		$settingsnew['jsdateformat'] = str_replace('yyyy', 'Y', $settingsnew['jsdateformat']);
		$settingsnew['jsdateformat'] = str_replace('yy', 'y', $settingsnew['jsdateformat']);
	}

	if(isset($settingsnew['wapdateformat'])) {
		$settingsnew['wapdateformat'] = str_replace('mm', 'n', $settingsnew['wapdateformat']);
		$settingsnew['wapdateformat'] = str_replace('dd', 'j', $settingsnew['wapdateformat']);
		$settingsnew['wapdateformat'] = str_replace('yyyy', 'Y', $settingsnew['wapdateformat']);
		$settingsnew['wapdateformat'] = str_replace('yy', 'y', $settingsnew['wapdateformat']);
	}

	if(isset($settingsnew['cachethreaddir']) && isset($settingsnew['threadcaches'])) {
		if($settingsnew['cachethreaddir'] && !is_writable(DISCUZ_ROOT.'./'.$settingsnew['cachethreaddir'])) {
			cpmsg('cachethread_dir_noexists');
		}
		if(!empty($fids)) {
			$sqladd = in_array('all', $fids) ? '' :  " WHERE fid IN ('".implode("', '", $fids)."')";
			$db->query("UPDATE {$tablepre}forums SET threadcaches='$settingsnew[threadcaches]'$sqladd");
		}
	}

	if(isset($settingsnew['msgforward'])) {
		if(!empty($settingsnew['msgforward']['messages'])) {
			$tempmsg = explode("\n", $settingsnew['msgforward']['messages']);
			$settingsnew['msgforward']['messages'] = array();
			foreach ($tempmsg as $msg) {
				if($msg = strip_tags(trim($msg))) {
					$settingsnew['msgforward']['messages'][] = $msg;
				}
			}
		} else {
			$settingsnew['msgforward']['messages'] = array();
		}

		$tmparray = array(
			'refreshtime' => intval($settingsnew['msgforward']['refreshtime']),
			'quick' => $settingsnew['msgforward']['quick'] ? 1 : 0,
			'messages' => $settingsnew['msgforward']['messages']
		);
		$settingsnew['msgforward'] = addslashes(serialize($tmparray));
	}

	foreach($settingsnew as $key => $val) {
		if(isset($settings[$key]) && $settings[$key] != $val) {
			$$key = $val;

			if(in_array($key, array('newbiespan', 'topicperpage', 'postperpage', 'memberperpage', 'hottopic', 'starthreshold', 'delayviewcount',
				'visitedforums', 'maxsigrows', 'timeoffset', 'statscachelife', 'pvfrequence', 'oltimespan', 'seccodestatus',
				'maxprice', 'rssttl', 'rewritestatus', 'bdaystatus', 'maxonlines', 'loadctrl', 'floodctrl', 'regctrl', 'regfloodctrl',
				'searchctrl', 'extcredits1', 'extcredits2', 'extcredits3', 'extcredits4', 'extcredits5', 'extcredits6',
				'extcredits7', 'extcredits8', 'transfermincredits', 'exchangemincredits', 'maxincperthread', 'maxchargespan',
				'maxspm', 'maxsearchresults', 'maxsmilies', 'threadmaxpages', 'membermaxpages', 'maxpostsize', 'minpostsize', 'maxavatarsize',
				'maxavatarpixel', 'maxpolloptions', 'karmaratelimit', 'losslessdel', 'edittimelimit', 'smcols',
				'watermarktrans', 'watermarkquality', 'jscachelife', 'waptpp', 'wapppp', 'wapmps', 'maxmodworksmonths', 'frameon', 'maxonlinelist'))) {
				$val = (float)$val;
			}
			if($key == 'forumlinkstatus') {
				updatecache('forumlinks');
			}
			if($key == 'userstatusby') {
				updatecache('usergroups');
			}
			if(($key == 'smthumb' && $val != $settings['smthumb']) || ($key == 'smcols' && $val != $settings['smcols']) || ($key == 'smrows' && $val != $settings['smrows'])) {
				updatecache(array('smilies_display', 'smiliestable'));
			}

			$db->query("REPLACE INTO {$tablepre}settings (variable, value)
				VALUES ('$key', '$val')");
		}
	}
	updatecache('settings');
	if($do == 'credits' && $projectsave) {
		$projectid = intval($projectid);
		dheader("Location: {$boardurl}admincp.php?action=projectadd&type=extcredit&projectid=$projectid");
	}
	$do == 'secqaa' && $lackofqaa ? cpmsg('secqaa_invalid', 'admincp.php?action=settings&do=secqaa') : cpmsg('settings_update_succeed');
}

?>
