<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: header.inc.php,v $
	$Revision: 1.8.2.1 $
	$Date: 2007/03/21 15:52:48 $
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

?>
<html>
<head>
<base href="<?=$boardurl?>">
<title><?=$navtitle?> <?=$_DCACHE['settings']['bbname']?> <?=$_DCACHE['settings']['seotitle']?> - powered by Discuz! Archiver</title>
<?=$_DCACHE['settings']['seohead']?>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$charset?>">
<meta name="keywords" content="Discuz!,Board,Comsenz,forums,bulletin board,<?=$_DCACHE['settings']['seokeywords']?>">
<meta name="description" content="<?=$meta_contentadd?> <?=$_DCACHE['settings']['bbname']?> <?=$_DCACHE['settings']['seodescription']?> - Discuz! Archiver">
<meta name="generator" content="Discuz! Archiver <?=$_DCACHE['settings']['version']?>">
<link rel="stylesheet" type="text/css" href="forumdata/cache/style_<?=$_DCACHE['settings']['styleid']?>.css">
</head>
<body leftmargin="10" rightmargin="10" topmargin="10"><center>
<div class="tableborder" style="background-color: <?=MAINTABLECOLOR?>">
