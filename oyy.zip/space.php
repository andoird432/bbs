<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: space.php,v $
	$Revision: 1.11.2.15 $
	$Date: 2007/05/31 15:05:46 $
*/

define('CURSCRIPT', 'space');

require_once './include/common.inc.php';
require_once DISCUZ_ROOT.'./include/space.func.php';
include_once DISCUZ_ROOT.'./forumdata/cache/cache_forums.php';
include_once language('spaces');

$discuz_action = 150;

$querystring = explode('/', $_SERVER['QUERY_STRING']);
$uid = !empty($uid) ? intval($uid) : intval($querystring[0]);
$username = !isset($username) || $uid ? '' : $username;
$mod = !empty($mod) ? $mod : $querystring[1];
$starttime = !empty($starttime) ? intval($starttime) : intval($querystring[2]);
$endtime = !empty($endtime) ? intval($endtime) : intval($querystring[3]);
$multipage = $titleextra = '';
$menulist = $modulelist = array();

$query = $db->query("SELECT m.*, mf.*, s.lastactivity as online
	FROM {$tablepre}members m
	LEFT JOIN {$tablepre}memberfields mf ON mf.uid=m.uid
	LEFT JOIN {$tablepre}sessions s ON s.uid=m.uid AND s.invisible='0'
	WHERE ".($uid ? "m.uid='$uid'" : "m.username='$username'")." LIMIT 1");
if(!$member = $db->fetch_array($query)) {
	showmessage('member_nonexistence');
}

$uid = $member['uid'];

if($spacestatus && $supe['status'] && $member['xspacestatus']) {
	dheader("location: $supe[siteurl]?uid/$uid");
}

if(!$spacestatus || in_array($member['groupid'], array(4, 5, 6))) {
	dheader("location: {$boardurl}viewpro.php?uid=$uid");
}

$spacesettings = getspacesettings($uid);

if(!empty($preview) && $uid == $discuz_uid) {
	$spacesettings['layout'] = explode('|', $preview);
	$spacesettings['side'] = intval($spaceside);
} else {
	$spacesettings['layout'] = explode("\t", $spacesettings['layout']);
}
if(!empty($style)) {
	$spacesettings['style'] = str_replace('/', '', $style);
	if(!file_exists(DISCUZ_ROOT.'./mspace/'.$spacesettings['style'].'/style.ini')) {
		showmessage('space_style_nofound', NULL, 'HALTED');
	}
}

foreach($spacesettings['layout'] as $k => $layoutitem) {
	$layout[$k] = explode('][', ']'.$layoutitem.'[');
	$layout[$k] = array_slice($layout[$k], 1, count($layout[$k]) - 2);
	$newlayout = array();
	foreach($layout[$k] as $module) {
		if(array_key_exists($module, $modulesettings)) {
			$newlayout[] = $module;
		}
	}
	$layout[$k] = $newlayout;
	$modulelist = array_merge($modulelist, $layout[$k]);
}

if(!empty($mod) && array_key_exists($mod, $listmodule)) {
	$spacelimit = 'spacelimit'.$mod;
	if(!intval($$spacelimit) || !in_array($mod, $modulelist)) {
		dheader("location: {$boardurl}space.php?uid=$uid");
	}
	if($spacesettings['side'] == 1) {
		$side = 0;
	} elseif($spacesettings['side'] == 2) {
		$side = 2;
	} else {
		$side = 0;
		$spacesettings['side'] = 1;
	}
	$layout[$side] = array('userinfo');
	$layout[1] = array($mod);
	$titleextra = ' - '.$spacelanguage[$mod];
	$moduledata[$mod]['value'] = updatespacecache($uid, $mod, TRUE);
	if($mod == 'myblogs') {
		$layout[$side][] = 'calendar';
		if($discuz_uid && $uid == $discuz_uid && $allowpost && $allowuseblog) {
			require_once DISCUZ_ROOT.'./include/forum.func.php';
			$forumselect = forumselect();
			if($discuz_uid == $uid) {
				$layout[$side][] = 'postblog';
			}
		}
		$layout[$side][] = 'hotblog';
		$hotblog = spacecaches($uid, array('hotblog'));
		$moduledata = array_merge($moduledata, $hotblog);
	}
} else {
	$moduledata = spacecaches($uid, $modulelist);
}

foreach($modulelist as $module) {
	$spacelimit = 'spacelimit'.$module;
	if(array_key_exists($module, $listmodule) && intval($$spacelimit)) {
		$menulist[$listmodule[$module]] = $module;
	}
}
ksort($menulist);

$moduledata['userinfo']['value'] = $member;

include template('space_module');
include template('space');

?>