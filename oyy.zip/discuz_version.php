<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: discuz_version.php,v $
	$Revision: 1.10.2.7 $
	$Date: 2007/07/24 13:48:03 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('DISCUZ_VERSION', '5.5.0');
define('DISCUZ_RELEASE', '20081117');

?>