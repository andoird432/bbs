<?php

// Misc Language Pack for Discuz! Version 1.0.0
// Translated by Crossday

$spacelanguage = array
(
	'space' => '的个人空间',
	'userinfo' => '个人信息',
	'calendar' => '日历',
	'mythreads' => '主题',
	'myreplies' => '回复',
	'myrewards' => '悬赏',
	'mytrades' => '商品',
	'myblogs' => '文集',
	'myfriends' => '好友',
	'myfavforums' => '收藏的论坛',
	'myfavthreads' => '收藏的帖子',
	'postblog' => '发表文集',
	'hotblog' => '最热的 5 篇文集'
);

?>